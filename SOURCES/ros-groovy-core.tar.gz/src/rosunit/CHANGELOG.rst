^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package rosunit
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.9.51 (2013-08-22)
-------------------

1.9.50 (2013-08-21)
-------------------
* make rosunit relocatable (`ros/catkin#490 <https://github.com/ros/catkin/issues/490>`_)

1.9.49 (2013-07-05)
-------------------

1.9.48 (2013-07-03)
-------------------
* check for CATKIN_ENABLE_TESTING to enable configure without tests

1.9.47 (2013-06-18)
-------------------

1.9.46 (2013-06-06)
-------------------
* make rosunit use print function for Python 2 and 3 compatibility (`#11 <https://github.com/ros/ros/issues/11>`_)
* remove unnecessary usage of unicode strings (`#12 <https://github.com/ros/ros/issues/12>`_)

1.9.45 (2013-03-22 09:18)
-------------------------

1.9.44 (2013-03-13)
-------------------

1.9.43 (2013-03-08)
-------------------
* fix handling spaces in folder names (`ros/catkin#375 <https://github.com/ros/catkin/issues/375>`_)

1.9.42 (2013-01-25)
-------------------

1.9.41 (2013-01-24)
-------------------

1.9.40 (2013-01-13)
-------------------

1.9.39 (2012-12-30)
-------------------
* first public release for Groovy
