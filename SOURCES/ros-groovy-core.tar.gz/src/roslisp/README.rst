roslisp
========

Common Lisp library for interaction with ROS (Robot operating system).

See http://www.ros.org/wiki/roslisp

Tested using SBCL.
