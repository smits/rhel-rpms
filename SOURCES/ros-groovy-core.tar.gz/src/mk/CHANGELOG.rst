^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package mk
^^^^^^^^^^^^^^^^^^^^^^^^

1.9.51 (2013-08-22)
-------------------

1.9.50 (2013-08-21)
-------------------

1.9.49 (2013-07-05)
-------------------
* update eclipse-project target to not try to delete CATKIN_IGNORE marker files and check before trying to delete other files/folders (`#20 <https://github.com/ros/ros/issues/20>`_)

1.9.48 (2013-07-03)
-------------------

1.9.47 (2013-06-18)
-------------------

1.9.46 (2013-06-06)
-------------------
* add missing environment exports to make eclipse-projects of dry packages build
* cleanup catkin generated files/directories after make eclips-project

1.9.45 (2013-03-22 09:18)
-------------------------

1.9.44 (2013-03-13)
-------------------

1.9.43 (2013-03-08)
-------------------

1.9.42 (2013-01-25)
-------------------

1.9.41 (2013-01-24)
-------------------
* modified install location of download_checkmd5 script to work in devel space and be consistent with other files

1.9.40 (2013-01-13)
-------------------

1.9.39 (2012-12-30)
-------------------
* first public release for Groovy
