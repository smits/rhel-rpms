rosinstall_generator
====================

Code & tickets
--------------

+----------------------+------------------------------------------------------------------+
| rosinstall_generator | http://github.com/ros-infrastructure/rosinstall_generator        |
+----------------------+------------------------------------------------------------------+
| Issues               | http://github.com/ros-infrastructure/rosinstall_generator/issues |
+----------------------+------------------------------------------------------------------+
